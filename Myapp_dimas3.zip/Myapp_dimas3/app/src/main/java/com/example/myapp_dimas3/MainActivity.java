package com.example.myapp_dimas3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText user;
    private EditText pass;
    private TextView outputText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user = findViewById(R.id.username);
        pass = findViewById(R.id.password);
        outputText=findViewById(R.id.text_output);
    }

    public void TombolSubmit(View view) {
        String user1;
        String pass1;
        user1 = String.valueOf(user.getText());
        pass1 = String.valueOf(pass.getText());
        if (user1.equals("dimas") && pass1.equals("dimas")){
            outputText.setText("Selamat! anda sudah login");
        }else{
            outputText.setText("Masukkan ulang password dan username");
        }
    }
}